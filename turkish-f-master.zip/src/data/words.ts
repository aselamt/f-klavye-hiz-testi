export const TURKISH_WORDS = [
    "bir", "bu", "ne", "ve", "için", "çok", "dedi", "gibi", "daha", "oldu",
    "var", "ben", "o", "de", "da", "sen", "kadar", "olan", "sonra", "ile",
    "ama", "her", "biz", "yer", "en", "diye", "iyi", "değil", "zaman", "ki",
    "nasıl", "hiç", "yok", "onu", "şey", "bunu", "bana", "yani", "kendi",
    "böyle", "artık", "geri", "önce", "bile", "şimdi", "yeni", "sadece",
    "bütün", "tek", "büyük", "güzel", "iki", "az", "uzun", "gün", "adam",
    "yıl", "iş", "ara", "el", "göz", "çocuk", "baba", "anne", "dünya",
    "devlet", "su", "hava", "yol", "kitap", "okul", "kapı", "ev", "oda",
    "masa", "söz", "ses", "baş", "can", "kan", "yan", "biraz"
];

export const SENTENCES = [
    "Bir elin nesi var iki elin sesi var",
    "Damlaya damlaya göl olur",
    "Sakla samanı gelir zamanı",
    "Gülme komşuna gelir başına",
    "Ayağını yorganına göre uzat",
    "İşleyen demir ışıldar",
    "Aslan yattığı yerden belli olur",
    "Bugünün işini yarına bırakma",
    "Komşu komşunun külüne muhtaçtır",
    "Üzüm üzüme baka baka kararır"
];
